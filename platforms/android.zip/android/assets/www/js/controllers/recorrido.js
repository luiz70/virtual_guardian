angular.module('starter')
.controller("recorrido",function($scope,$http,$rootScope,CordovaNetwork,$location){
	
	$scope.inicializa=function(){
	};
})